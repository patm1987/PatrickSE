/*
 * Created on May 12, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package pJModules.utilModules;

/**
 * @author patm1987
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */

/*
 * 
 * in order for a button to do anything, you need to
 * create an action for it
 * 
 * this action handles mouseover
 * mouseout
 * and mouseclick
 * 
 */

public interface PJButtonAction {
	public void onMouseover();
	public void onMouseout();
	public void onMouseclick();
}
