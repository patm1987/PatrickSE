/*
 * Created on May 12, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package pJModules.utilModules;

/**
 * @author patm1987
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 * 
 * This is a basic button.  it does not care about the position
 * of a click, since it would not have child objects nor need
 * to keep track of a mouse position
 * 
 * to have the button do anything, you need to create a class
 * that implements pJModules.utilModules.PJButtonAction() so
 * that something actually happens.
 */
import java.awt.image.*;
import java.awt.*;

public class PJImageButton extends basicModule {
	private PJButtonAction myPJButtonAction;
	private BufferedImage myImage;
	private boolean isMouseOver;
	
	public PJImageButton(float x, float y, BufferedImage img, PJButtonAction ba){
		super(x, y, img.getWidth(), img.getHeight(), true);
		myPJButtonAction = ba;
		myImage = img;
		isMouseOver = false;
		createImage();
	}

	/* (non-Javadoc)
	 * @see utilModules.basicModule#createImage()
	 */
	protected void createImage() {
		// TODO Auto-generated method stub
		BufferedImage tempbi = super.getNewBufferedImage();
		Graphics2D g2d = (Graphics2D)tempbi.createGraphics();
		if (!isMouseOver){
			Composite alphaComp = AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.75f);
			g2d.setComposite(alphaComp);
		}
		else{
			Composite alphaComp = AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 1f);
			g2d.setComposite(alphaComp);
		}
		if (myImage != null)
			g2d.drawImage(myImage, null, 0, 0);
		g2d.dispose();
	}
	
	public void onMouseover(){
		if (!isMouseOver){
			isMouseOver = true;
			myPJButtonAction.onMouseover();
			createImage();
		}
	}
	
	public void onMouseout(){
		if (isMouseOver){
			isMouseOver = false;
			myPJButtonAction.onMouseout();
			createImage();
		}
	}
	
	public void onMouseclick(){
		myPJButtonAction.onMouseclick();
	}

}
