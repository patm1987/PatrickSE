/*
 * Created on May 12, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package pJModules.utilModules;

import java.awt.image.BufferedImage;

import pJCanvas.Boundary;
import pJCanvas.Location;
import pJCanvas.PJModule;

/**
 * @author patm1987
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */

/* 
 * This is a basic class to get you started making modules
 * */
/*
 * @author patm1987
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public abstract class basicModule implements PJModule {
	private Location myPosition;
	private Boundary myBounds;
	private boolean Visible;
	private BufferedImage bi;
	
	//the basic constructor, takes position, width, height, and visibility
	public basicModule(float x, float y, int w, int h, boolean vis){
		setup(x, y, false, false, w, h, vis);
	}
	
	//x position, y position, flip the x, flip the y, width, height, visibility
	//remember that flipping the x or y means swapping which corner of the module
	//clicks and rendering will be considered from
	public basicModule(float x, float y, boolean fx, boolean fy, int w, int h, boolean vis){
		setup(x, y, fx, fy, w, h, vis);
	}
	
	protected void setup(float x, float y, boolean fx, boolean fy, int w, int h, boolean vis){
		myPosition = new Location (x, y, fx, fy);
		myBounds = new Boundary(w, h);
		Visible = vis;
		bi = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
		createImage();
	}
	
	
	/*
	 * 
	 * This creates the image to render
	 * you must impliment this in some way
	 * use the getBufferedImage method to get the image
	 * currently in use, and getNewBufferedImage to get
	 * a new image to write to
	 * 
	 * if you don't want to override update()
	 * do not create your own buffered image, use the one
	 * privided by getNewBufferedImage()
	 * 
	 */
	protected abstract void createImage();
	
	//get the current buffered image for drawing
	//this means that nothing is refreshed, and you're
	//drawing on top of the image you are using instead of
	//getting a blank one
	protected BufferedImage getBufferedImage(){
		return bi;
	}
	
	//get a new, blank, buffer
	protected BufferedImage getNewBufferedImage(){
		bi = new BufferedImage (myBounds.getWidth(), myBounds.getHeight(), BufferedImage.TYPE_INT_ARGB);
		return bi;
	}
	
	/* (non-Javadoc)
	 * @see pJCanvas.PJModule#getBounds()
	 */
	public Boundary getBounds() {
		// TODO Auto-generated method stub
		return myBounds;
	}
	/* (non-Javadoc)
	 * @see pJCanvas.PJModule#getHeight()
	 */
	public int getHeight() {
		// TODO Auto-generated method stub
		return myBounds.getHeight();
	}
	/* (non-Javadoc)
	 * @see pJCanvas.PJModule#getPosition()
	 */
	public Location getPosition() {
		// TODO Auto-generated method stub
		return myPosition;
	}
	/* (non-Javadoc)
	 * @see pJCanvas.PJModule#getWidth()
	 */
	public int getWidth() {
		// TODO Auto-generated method stub
		return myBounds.getWidth();
	}
	/* (non-Javadoc)
	 * @see pJCanvas.PJModule#getX()
	 */
	public float getX() {
		// TODO Auto-generated method stub
		return myPosition.getX();
	}
	/* (non-Javadoc)
	 * @see pJCanvas.PJModule#getY()
	 */
	public float getY() {
		// TODO Auto-generated method stub
		return myPosition.getY();
	}
	/* (non-Javadoc)
	 * @see pJCanvas.PJModule#isVisible()
	 */
	public boolean isVisible() {
		// TODO Auto-generated method stub
		return Visible;
	}
	/* (non-Javadoc)
	 * @see pJCanvas.PJModule#isXFlipped()
	 */
	public boolean isXFlipped() {
		// TODO Auto-generated method stub
		return myPosition.isXFlipped();
	}
	/* (non-Javadoc)
	 * @see pJCanvas.PJModule#isYFlipped()
	 */
	public boolean isYFlipped() {
		// TODO Auto-generated method stub
		return myPosition.isYFlipped();
	}
	/* (non-Javadoc)
	 * @see pJCanvas.PJModule#setBounds(pJCanvas.Boundary)
	 */
	public void setBounds(Boundary bound) {
		// TODO Auto-generated method stub
		myBounds = bound;
	}
	/* (non-Javadoc)
	 * @see pJCanvas.PJModule#setBounds(int, int)
	 */
	public void setBounds(int width, int height) {
		// TODO Auto-generated method stub
		myBounds.setBounds(width, height);
	}
	/* (non-Javadoc)
	 * @see pJCanvas.PJModule#setHeight(int)
	 */
	public void setHeight(int height) {
		// TODO Auto-generated method stub
		myBounds.setHeight(height);
	}
	/* (non-Javadoc)
	 * @see pJCanvas.PJModule#setPosition(float, float, boolean, boolean)
	 */
	public void setPosition(float x, float y, boolean fx, boolean fy) {
		// TODO Auto-generated method stub
		myPosition.set(x, y, fx, fy);
	}
	/* (non-Javadoc)
	 * @see pJCanvas.PJModule#setPosition(pJCanvas.Location)
	 */
	public void setPosition(Location loc) {
		// TODO Auto-generated method stub
		myPosition.set(loc);
	}
	/* (non-Javadoc)
	 * @see pJCanvas.PJModule#setVisible(boolean)
	 */
	public void setVisible(boolean vis) {
		// TODO Auto-generated method stub
		Visible = vis;
	}
	/* (non-Javadoc)
	 * @see pJCanvas.PJModule#setWidth(int)
	 */
	public void setWidth(int width) {
		// TODO Auto-generated method stub
		myBounds.setWidth(width);
	}
	/* (non-Javadoc)
	 * @see pJCanvas.PJModule#setX(float)
	 */
	public void setX(float x) {
		// TODO Auto-generated method stub
		myPosition.setX(x);
	}
	/* (non-Javadoc)
	 * @see pJCanvas.PJModule#setXFlipped(boolean)
	 */
	public void setXFlipped(boolean fx) {
		// TODO Auto-generated method stub
		myPosition.setXFlipped(fx);
	}
	/* (non-Javadoc)
	 * @see pJCanvas.PJModule#setY(float)
	 */
	public void setY(float y) {
		// TODO Auto-generated method stub
		myPosition.setY(y);
	}
	/* (non-Javadoc)
	 * @see pJCanvas.PJModule#setYFlipped(boolean)
	 */
	public void setYFlipped(boolean fy) {
		// TODO Auto-generated method stub
		myPosition.setYFlipped(fy);
	}
	/* (non-Javadoc)
	 * @see pJCanvas.PJModule#update()
	 */
	public BufferedImage update() {
		// TODO Auto-generated method stub
		return bi;
	}
	/* (non-Javadoc)
	 * @see pJCanvas.PJModule#onMouseclick(int, float, float)
	 */
	public void onMouseclick(int button, float x, float y) {
		// TODO Auto-generated method stub

	}
	/* (non-Javadoc)
	 * @see pJCanvas.PJModule#onMouseout(float, float)
	 */
	public void onMouseout(float x, float y) {
		// TODO Auto-generated method stub

	}
	/* (non-Javadoc)
	 * @see pJCanvas.PJModule#onMouseover(float, float)
	 */
	public void onMouseover(float x, float y) {
		// TODO Auto-generated method stub

	}
}
