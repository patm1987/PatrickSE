/*
 * Created on May 13, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package pJModules.testModule;

import pJModules.utilModules.*;
import javax.swing.*;
import java.awt.image.*;
import java.awt.*;

/**
 * @author patm1987
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
//a simple test of a button
public class testButton extends basicModule {
	
	private PJImageButton myImageButton;
	
	public testButton(float x, float y){
		super(x, y, 48, 48, true);
		
		ImageIcon imic = new ImageIcon ("icons/mozilla.png");
		
		BufferedImage bbi = new BufferedImage (48, 48, BufferedImage.TYPE_INT_ARGB);
		Graphics bg2d = bbi.createGraphics();
		
		//bg2d.setColor(Color.pink);
		//bg2d.fillRect(0, 0, 48, 48);
		
		bg2d.drawImage(imic.getImage(), 0, 0, null);
		
		myImageButton = new PJImageButton(0, 0, bbi, new testButtonAction());
		bg2d.dispose();
		
		createImage();
	}

	/* (non-Javadoc)
	 * @see pJModules.utilModules.basicModule#createImage()
	 */
	protected void createImage() {
		BufferedImage bi = super.getBufferedImage();
		Graphics2D g2d = (Graphics2D)bi.createGraphics();
		if (myImageButton != null)
			g2d.drawImage(myImageButton.update(), null, 0, 0);
		g2d.dispose();
	}
	
	private class testButtonAction implements PJButtonAction{

		/* (non-Javadoc)
		 * @see pJModules.utilModules.PJButtonAction#onMouseover()
		 */
		public void onMouseover() {
			// TODO Auto-generated method stub
			
		}

		/* (non-Javadoc)
		 * @see pJModules.utilModules.PJButtonAction#onMouseout()
		 */
		public void onMouseout() {
			// TODO Auto-generated method stub
			
		}

		/* (non-Javadoc)
		 * @see pJModules.utilModules.PJButtonAction#onMouseclick()
		 */
		public void onMouseclick() {
			// TODO Auto-generated method stub
			
		}
		
	}
	
}
