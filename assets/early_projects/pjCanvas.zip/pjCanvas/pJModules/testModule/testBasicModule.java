/*
 * Created on May 13, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package pJModules.testModule;

import pJModules.utilModules.basicModule;

/**
 * @author patm1987
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */

import java.awt.image.*;
import java.awt.*;

//A simple module based off the abstract class basicModule
//all modules should extend basicModule unless you need more
//complicated functionality
public class testBasicModule extends basicModule{

	/* (non-Javadoc)
	 * @see pJModules.utilModules.basicModule#createImage()
	 */
	
	public testBasicModule(float x, float y){
		super(x, y, 100, 100, true);
	}
	
	protected void createImage() {
		// TODO Auto-generated method stub
		BufferedImage bi = super.getBufferedImage();
		Graphics2D g2d = (Graphics2D)bi.createGraphics();
		g2d.setColor(Color.ORANGE);
		g2d.fillOval(0, 0, 100, 100);
		g2d.dispose();
	}
	
}
