/*
 * Created on May 11, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package pJModules.testModule;
import java.awt.image.*;
import java.awt.*;

/**
 * @author patm1987
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */

//test the ability for a module to change position, also
//a very entertaining bouncing box
public class testModuleMove extends testModule {
	private boolean goingUp = false;
	private float myDistancePerStep;
	
	public testModuleMove (float x, float y, float d, int w, int h, Color col){
		super(x, y, w, h, col);
		myDistancePerStep = d;
	}
	
	public BufferedImage update(){
		if (this.getY() > 1 || this.getY() < 0){
			goingUp = !goingUp;
		}
		
		if (goingUp){
			this.setY(this.getY()-myDistancePerStep);
		}
		else{
			this.setY(this.getY()+myDistancePerStep);
		}
		return super.update();
	}
}
