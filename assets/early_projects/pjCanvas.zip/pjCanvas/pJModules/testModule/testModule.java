/*
 * Created on May 11, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package pJModules.testModule;

import java.awt.image.BufferedImage;

import pJCanvas.Boundary;
import pJCanvas.Location;
import pJCanvas.PJModule;

import java.util.Random;

import java.awt.*;

/**
 * @author patm1987
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */

//test a module, implements PJModule, extend basic module
//unless it can not provide desired functionality, if not
//then implement PJModule
public class testModule implements PJModule {
	
	private Boundary myBoundary;
	private Location myPosition;
	private boolean Visible;
	private Color myColor;
	private BufferedImage bi;
	
	public testModule(){
		myPosition = new Location (0f, 0f);
		myBoundary = new Boundary (50, 50);
		Visible = true;
		myColor = Color.blue;
		createImage();
	}
	
	public testModule(float x, float y, int width, int height, Color color){
		myPosition = new Location (x, y);
		myBoundary = new Boundary (width, height);
		Visible = true;
		myColor = color;
		createImage();
	}
	
	private void createImage(){
		bi = new BufferedImage (getWidth(), getHeight(), BufferedImage.TYPE_INT_ARGB);
		Graphics2D g2d = bi.createGraphics();
		g2d.setColor(myColor);
		g2d.fillRect(0, 0, bi.getWidth(), bi.getHeight());
		g2d.dispose();
	}
	
	/* (non-Javadoc)
	 * @see pJCanvas.PJModule#getPosition()
	 */
	public Location getPosition() {
		// TODO Auto-generated method stub
		return myPosition;
	}

	/* (non-Javadoc)
	 * @see pJCanvas.PJModule#getX()
	 */
	public float getX() {
		// TODO Auto-generated method stub
		return myPosition.getX();
	}

	/* (non-Javadoc)
	 * @see pJCanvas.PJModule#getY()
	 */
	public float getY() {
		// TODO Auto-generated method stub
		return myPosition.getY();
	}
	
	public boolean isXFlipped(){
		return myPosition.isXFlipped();
	}
	
	public boolean isYFlipped(){
		return myPosition.isYFlipped();
	}

	/* (non-Javadoc)
	 * @see pJCanvas.PJModule#getBounds()
	 */
	public Boundary getBounds() {
		// TODO Auto-generated method stub
		return myBoundary;
	}

	/* (non-Javadoc)
	 * @see pJCanvas.PJModule#getWidth()
	 */
	public int getWidth() {
		// TODO Auto-generated method stub
		return myBoundary.getWidth();
	}

	/* (non-Javadoc)
	 * @see pJCanvas.PJModule#getHeight()
	 */
	public int getHeight() {
		// TODO Auto-generated method stub
		return myBoundary.getHeight();
	}

	/* (non-Javadoc)
	 * @see pJCanvas.PJModule#isVisible()
	 */
	public boolean isVisible() {
		// TODO Auto-generated method stub
		return Visible;
	}

	/* (non-Javadoc)
	 * @see pJCanvas.PJModule#update()
	 */
	public BufferedImage update() {
		// TODO Auto-generated method stub
		return bi;
	}

	/* (non-Javadoc)
	 * @see pJCanvas.PJModule#setPosition(pJCanvas.Location)
	 */
	public void setPosition(Location loc) {
		// TODO Auto-generated method stub
		myPosition.set(loc);
	}

	/* (non-Javadoc)
	 * @see pJCanvas.PJModule#setPosition(double, double)
	 */
	public void setPosition(float x, float y, boolean fx, boolean fy) {
		// TODO Auto-generated method stub
		myPosition.set(x, y, fx, fy);
	}

	/* (non-Javadoc)
	 * @see pJCanvas.PJModule#setX(double)
	 */
	public void setX(float x) {
		// TODO Auto-generated method stub
		myPosition.setX(x);
	}

	/* (non-Javadoc)
	 * @see pJCanvas.PJModule#setY(double)
	 */
	public void setY(float y) {
		// TODO Auto-generated method stub
		myPosition.setY(y);
	}
	
	public void setXFlipped(boolean fx){
		myPosition.setXFlipped(fx);
	}
	
	public void setYFlipped(boolean fy){
		myPosition.setYFlipped(fy);
	}

	/* (non-Javadoc)
	 * @see pJCanvas.PJModule#setBounds(pJCanvas.Boundary)
	 */
	public void setBounds(Boundary bound) {
		// TODO Auto-generated method stub
		myBoundary.setBounds(bound);
	}

	/* (non-Javadoc)
	 * @see pJCanvas.PJModule#setBounds(double, double)
	 */
	public void setBounds(int width, int height) {
		// TODO Auto-generated method stub
		myBoundary.setBounds(width, height);
	}

	/* (non-Javadoc)
	 * @see pJCanvas.PJModule#setWidth(double)
	 */
	public void setWidth(int width) {
		// TODO Auto-generated method stub
		myBoundary.setWidth(width);
	}

	/* (non-Javadoc)
	 * @see pJCanvas.PJModule#setHeight(double)
	 */
	public void setHeight(int height) {
		// TODO Auto-generated method stub
		myBoundary.setHeight(height);
	}

	/* (non-Javadoc)
	 * @see pJCanvas.PJModule#setVisible(boolean)
	 */
	public void setVisible(boolean vis) {
		// TODO Auto-generated method stub
		Visible = vis;
	}

	/* (non-Javadoc)
	 * @see pJCanvas.PJModule#onMouseover()
	 */
	public void onMouseover(float x, float y) {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see pJCanvas.PJModule#onMouseout()
	 */
	public void onMouseout(float x, float y) {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see pJCanvas.PJModule#onMouseclick(int, int, int)
	 */
	public void onMouseclick(int button, float x, float y) {
		// TODO Auto-generated method stub
		Random tempRand = new Random();
		myColor = new Color (tempRand.nextFloat(), tempRand.nextFloat(), tempRand.nextFloat(), tempRand.nextFloat());
		createImage();
	}
	
	public String toString(){
		return "TestObject at " + myPosition + " that is " + myColor;
	}

}
