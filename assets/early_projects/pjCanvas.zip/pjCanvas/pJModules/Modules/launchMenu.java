/*
 * Created on May 20, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package pJModules.Modules;

import pJModules.utilModules.PJButtonAction;
import pJModules.utilModules.basicModule;
import pJModules.utilModules.PJImageButton;
import java.awt.*;
import java.awt.image.*;

/**
 * @author patm1987
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 * 
 * This is a "launch menu"
 * similar to the "start menu" in windows, and can take
 * objects like the IconBar.  This is useful since it maintains
 * screen space by hiding itself
 * 
 * place with an x and y coordinate, whether or not to flip
 * the hotspot for the x or y, and how many entries it can
 * take
 */
public class launchMenu extends basicModule {
	private boolean isExpanded;
	private PJImageButton[] myModuleList;
	
	//the shrunken sizes
	private int mySX, mySY;
	
	//the expanded sizes
	private int myEX, myEY;
	
	//x pos, y pos, flip the hotspot x, flip it y, number of slots
	public launchMenu (float x, float y, boolean fx, boolean fy, int s){
		super(x, y, fx, fy, 100, 25, true);
		
		//set the default sizes
		mySX = 100;
		mySY = 25;
		myEX = 200;
		//each item will have 25 pixels of space
		myEY = (s+1)*25;
		
		myModuleList = new PJImageButton[s];
		this.createImage();
	}

	/* (non-Javadoc)
	 * @see pJModules.utilModules.basicModule#createImage()
	 */
	protected void createImage() {
		// TODO Auto-generated method stub
		BufferedImage bi = super.getNewBufferedImage();
		Graphics2D g2d = (Graphics2D)bi.createGraphics();
		
		g2d.setColor(new Color(0f, 0f, 0f, .75f));
		g2d.fillRoundRect(-25, 0, bi.getWidth()+25, bi.getHeight()+25, 25, 25);
		
		g2d.setColor(new Color(1f, 1f, 1f, 1f));
		g2d.setFont(new Font("SansSerif", Font.BOLD, 21));
		if (isExpanded){
			g2d.drawString("Launch", 7, bi.getHeight()-4);
			drawExpanded(g2d);
		}
		else{
			g2d.drawString("Launch", 7, 21);
		}
		
		g2d.dispose();
	}
	
	//draw the more complicated expanded form
	private void drawExpanded(Graphics2D g2d){
		for (int x=0; x<myModuleList.length; x++){
			if (myModuleList[x] == null){
				break;
			}
			else{
				g2d.drawImage(myModuleList[x].update(), null, 0, x*25);
			}
		}
	}
	
	/*
	 * add an item
	 * i = item name as it will appear
	 * c = command to launch
	 * */
	public boolean addItem(String i, String c){
		
		if (myModuleList[myModuleList.length-1] != null){
			System.out.println("The bar is full");
			return false;
		}
		
		BufferedImage bi = new BufferedImage(myEX, mySY, BufferedImage.TYPE_INT_ARGB);
		Graphics2D g2d = (Graphics2D)bi.createGraphics();
		g2d.setColor(new Color (0, 0, 0, 255));
		g2d.fillRoundRect(0, 0, bi.getWidth(), bi.getHeight(), bi.getHeight(), bi.getHeight());
		g2d.setFont(new Font("SansSerif", Font.BOLD, 21));
		g2d.setColor(new Color (1f, 1f, 1f, 1f));
		g2d.drawString(i, 7, 21);
		

		g2d.dispose();
		
		myButtonAction ba = new myButtonAction(c);
		
		PJImageButton tempButton = new PJImageButton(bi.getWidth(), bi.getHeight(), bi, ba);
		
		for (int x=0; x<myModuleList.length; x++){
			if (myModuleList[x] == null){
				myModuleList[x] = tempButton;
				break;
			}
		}
		
		return true;
	}
	
	//handle mouse clicks
	//detects where the user clicks, if on a module, which
	//module, and whether or not the module is expanded
	public void onMouseclick (int b, float x, float y){
		
		PJImageButton tempButton = null;
		
		if (!isExpanded){
			super.setWidth(myEX);
			super.setHeight(myEY);
		}
		else {
			//calculate to a double
			double dModuleNumber = y*this.getHeight()/mySY-1;
			//invert and convert to an int
			int moduleNumber = 14-(int)dModuleNumber;
			
			if (moduleNumber >= 0 && (int)moduleNumber < myModuleList.length){
				tempButton = myModuleList[(int)moduleNumber];
			}
			
			if (tempButton != null){
				tempButton.onMouseclick();
			}
			
			super.setWidth(mySX);
			super.setHeight(mySY);
		}
		isExpanded = !isExpanded;
		createImage();
	}
	
	private class myButtonAction  implements PJButtonAction{
		private String myCommand;
		
		//takes a command
		public myButtonAction (String c){
			myCommand = c;
		}
		
		/* (non-Javadoc)
		 * @see pJModules.utilModules.PJButtonAction#onMouseover()
		 */
		public void onMouseover() {
			// TODO Auto-generated method stub
			
		}

		/* (non-Javadoc)
		 * @see pJModules.utilModules.PJButtonAction#onMouseout()
		 */
		public void onMouseout() {
			// TODO Auto-generated method stub
			
		}

		/* (non-Javadoc)
		 * @see pJModules.utilModules.PJButtonAction#onMouseclick()
		 */
		public void onMouseclick() {
			// TODO Auto-generated method stub
			try {
				Process game = Runtime.getRuntime().exec (myCommand);
			}catch (Exception re){ System.out.println ("An error has occoured:\n" + re); }
		}
		
	}
	
}
