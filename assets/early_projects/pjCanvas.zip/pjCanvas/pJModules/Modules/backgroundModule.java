/*
 * Created on May 15, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package pJModules.Modules;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;

import javax.swing.ImageIcon;

import pJModules.utilModules.basicModule;

/**
 * @author patm1987
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */

/*
 * This is a very simple module that simply fills itself with
 * a given image
 * it requires no position as it will be put into 0f, 0f, and
 * desires merley how big to draw it, in pixels
 */
public class backgroundModule extends basicModule {
	private BufferedImage myBufferedImage;
	
	public backgroundModule(String PathToImage, int w, int h){
		super(0, 0, w, h, true);
		
		//Create the buffered image
		ImageIcon imic = new ImageIcon (PathToImage);
		
		myBufferedImage = new BufferedImage (w, h, BufferedImage.TYPE_INT_ARGB);
		Graphics bg2d = myBufferedImage.createGraphics();
		
		bg2d.drawImage(imic.getImage(), 0, 0, null);
		bg2d.dispose();
		
		createImage();
	}
	/* (non-Javadoc)
	 * @see pJModules.utilModules.basicModule#createImage()
	 */
	protected void createImage() {
		// TODO Auto-generated method stub
		if (myBufferedImage != null){
			BufferedImage tempBuf = super.getNewBufferedImage();
			Graphics2D g2d = (Graphics2D)tempBuf.createGraphics();
			g2d.drawImage(myBufferedImage, null, 0, 0);
			g2d.dispose();
		}
	}

}
