/*
 * Created on May 13, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package pJModules.Modules;

/**
 * @author patm1987
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */

/*
 * this is a basic icon bar
 * it loads a default list of components, and can have more
 * added
 * 
 * in the future it may be able to read from file
 * but for now, everything is hard coded
 * 
 * basic idea:
 * start in upper left (no need to impliment moving hotspots
 * yet) and add a 48x48 icon
 * 
 * if you add an icon of a size greater than 48x48, it will
 * be clipped to 48x48, if you add one smaller, it will still
 * have a border reaching to 48x48
 * Yes, this means that I hardcoded the size 48x48 in
 * why? because the iconset I'm using uses 48x48, and it's a
 * good size.
 * 
 */

import java.awt.*;
import java.awt.image.*;

import javax.swing.*;
import pJModules.utilModules.*;

public class IconBar extends basicModule {
	
	private PJImageButton[] imageList;
	//the last module to be highlighted
	private PJImageButton lastHighlighted;
	
	private int myNumberOfIcons;

	/**
	 * @param x
	 * @param y
	 * @param w
	 * @param h
	 * @param vis
	 */
	public IconBar(float x, float y, int numIcons) {
		super(x, y, 20, 50, true);
		
		myNumberOfIcons = 0;
		
		imageList = new PJImageButton[numIcons];
		lastHighlighted = null;
		
		// TODO Auto-generated constructor stub
	}
	
	//returns true if icon is successfully added
	public boolean addIcon(String PathToImage, String command){
		
		if (imageList[imageList.length-1] != null){
			System.out.println ("Sorry, icon bar is full");
			return false;
		}
		
		ImageIcon imic = new ImageIcon (PathToImage);
		
		BufferedImage bbi = new BufferedImage (48, 48, BufferedImage.TYPE_INT_ARGB);
		Graphics bg2d = bbi.createGraphics();
		
		bg2d.drawImage(imic.getImage(), 0, 0, null);
		
		PJImageButton ib = new PJImageButton(0, 0, bbi, new execCommandAction(command));
		bg2d.dispose();
		
		for (int x=0; x<imageList.length; x++){
			if (imageList[x] == null){
				imageList[x] = ib;
				imageList[x].setPosition(52f*x, 0f, false, false);
				break;
			}
		}
		
		myNumberOfIcons++;
		
		createImage();
		
		return true;
	}

	/* (non-Javadoc)
	 * @see pJModules.utilModules.basicModule#createImage()
	 */
	protected void createImage() {
		// TODO Auto-generated method stub
		
		/*I am keeping g in case I need to render images
		 * here*/
		if (imageList != null){
			super.setWidth(myNumberOfIcons*52);
			
			BufferedImage bi = super.getNewBufferedImage();
			Graphics g = bi.createGraphics();
			Graphics2D g2d = (Graphics2D)g.create();
			
			g2d.setColor(new Color(89, 124, 192, (int)(255*.75)));
			g2d.fillRoundRect(0, 0, super.getWidth(), super.getHeight(), super.getHeight(), super.getHeight());
			for (int x=0; x<imageList.length; x++){
				if (imageList[x] != null)
					g2d.drawImage(imageList[x].update(), null, 52*x, 2);
			}
			
			g2d.dispose();
			g.dispose();
		}
	}
	
	//the mouseclick now has to figure out which module
	//you clicked on, and tell that module you clicked on it
	
	//remeber that each module is responsible for it's sub
	//modules, notice that the position is not passed, that's
	//because buttons don't care about where you click on them,
	//but don't add them as modules to a canvas, they are meant
	//to be submodules
	public void onMouseclick(int mb, float x, float y){
		float indexX = x*((float)super.getWidth()/52f);
		
		if (imageList[(int)indexX] != null){
			imageList[(int)indexX].onMouseclick();
		}
	}
	
	//pass a mouseover even on down the line
	public void onMouseover(float x, float y){
		float indexX = x*((float)super.getWidth()/52f);
		
		if (imageList[(int)indexX] != null){
			imageList[(int)indexX].onMouseover();
			lastHighlighted = imageList[(int)indexX];
			this.createImage();
		}
	}
	
	//tell the module you no longer like it , and have moved
	//the mouse somewhere else
	public void onMouseout(float x, float y){
		if (lastHighlighted != null){
			lastHighlighted.onMouseout();
			lastHighlighted = null;
		}
		else{
			for (int i=0; i<imageList.length; i++){
				if (imageList[i] != null)
					imageList[i].onMouseout();
			}
		}
		this.createImage();
	}
	
	//what should a button do?  this class defines the behavior
	//of a button
	private class execCommandAction implements PJButtonAction{
		private String myCommand;
		
		public execCommandAction (String command){
			myCommand = command;
		}
		
		/* (non-Javadoc)
		 * @see pJModules.utilModules.PJButtonAction#onMouseover()
		 */
		public void onMouseover() {
			// TODO Auto-generated method stub
			
		}

		/* (non-Javadoc)
		 * @see pJModules.utilModules.PJButtonAction#onMouseout()
		 */
		public void onMouseout() {
			// TODO Auto-generated method stub
			
		}

		/* (non-Javadoc)
		 * @see pJModules.utilModules.PJButtonAction#onMouseclick()
		 */
		public void onMouseclick() {
			// TODO Auto-generated method stub
			try {
				Process game = Runtime.getRuntime().exec (myCommand);
			}catch (Exception re){ System.out.println ("An error has occoured:\n" + re); }
		}
		
	}
	
}
