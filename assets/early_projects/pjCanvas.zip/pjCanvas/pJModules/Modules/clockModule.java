/*
 * Created on May 19, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package pJModules.Modules;

import pJModules.utilModules.basicModule;
import java.awt.*;
import java.awt.image.*;
import java.util.*;
import java.text.SimpleDateFormat;

/** 
 * @author patm1987
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */

/*
 * Another simple module, it is locked to the upper right
 * corner of the screen, it does not matter the size of the
 * canvas it is being drawn to, it will always be in the upper
 * right.
 * 
 * takes no input, simply a display
 */
public class clockModule extends basicModule {
	
	private final String timeFormat = "HH:mm:ss";
	private Calendar currentTime;
	private SimpleDateFormat mySdf;
	
	public clockModule(){
		super(1f, 0f, true, false, 100, 25, true);
		currentTime = Calendar.getInstance(TimeZone.getDefault());

    	mySdf = new SimpleDateFormat(timeFormat);  
		//createImage();
	}

	/* (non-Javadoc)
	 * @see pJModules.utilModules.basicModule#createImage()
	 */
	protected void createImage() {
		// TODO Auto-generated method stub
		
		BufferedImage bi = super.getNewBufferedImage();
		Graphics2D g2d = (Graphics2D)bi.createGraphics();
		
		g2d.setColor(new Color(.74509804f, 1f, 0f, .7f));
		g2d.fillRoundRect(0, 0, super.getWidth(), super.getHeight(), super.getHeight(), super.getHeight());
		
		//print time
		g2d.setColor(Color.BLACK);
		g2d.setFont(new Font("SansSerif", Font.BOLD, 15));
		
	    if (currentTime != null){
	    	currentTime = Calendar.getInstance(TimeZone.getDefault());
	    	g2d.drawString(mySdf.format(currentTime.getTime()) + "", 17, 18);//string width height
	    }
	    else
	    	g2d.drawString("Please Wait", 5, 20);
		
		g2d.dispose();

	}
	
	public BufferedImage update(){
		createImage();
		return super.update();
	}

}
