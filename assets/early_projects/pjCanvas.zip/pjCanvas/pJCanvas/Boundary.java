/*
 * Created on May 10, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package pJCanvas;

/**
 * @author martinp
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */

/*
 * Maintains a boundary in pixels
 * allows adjustment of said boundary
 */

public class Boundary {
	private int myWidth;
	private int myHeight;
	
	//constructors
	public Boundary(){
		myWidth = 0;
		myHeight = 0;
	}
	
	public Boundary (int width, int height){
		myWidth = width;
		myHeight = height;
	}
	
	public Boundary (Boundary bound){
		myWidth = bound.getWidth();
		myHeight = bound.getHeight();
	}
	
	//accessors
	public int getWidth(){
		return myWidth;
	}
	
	public int getHeight(){
		return myHeight;
	}
	
	public Boundary getBounds(){
		return new Boundary (this);
	}
	
	public String toString (){
		return "(" + getWidth() + ", " + getHeight() + ")";
	}
	
	//modifiers
	public void setWidth (int width){
		myWidth = width;
	}
	
	public void setHeight (int height){
		myHeight = height;
	}
	
	public void setBounds (int width, int height){
		myWidth = width;
		myHeight = height;
	}
	
	public void setBounds (Boundary bound){
		myWidth = bound.getWidth();
		myHeight = bound.getHeight();
	}
}
