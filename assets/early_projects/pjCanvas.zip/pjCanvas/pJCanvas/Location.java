/*
 * Created on May 10, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package pJCanvas;

/**
 * @author martinp
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */

/*
 * Maintains a location in percent
 * 1f = 100%
 * 0.5f = 50%
 * 0f = 0%
 * 
 * said location can be modified
 */
public class Location {
	private float posX;
	private float posY;
	private boolean flipX;
	private boolean flipY;
	
	//constructors
	public Location(){
		constructLocation(0f, 0f, false, false);
	}
	
	public Location (float x, float y){
		constructLocation(x, y, false, false);
	}
	
	public Location (Location loc){
		constructLocation(loc.getX(), loc.getY(), false, false);
	}
	
	public Location (float x, float y, boolean fx, boolean fy){
		constructLocation(x, y, fx, fy);
	}
	
	private void constructLocation(float x, float y, boolean fx, boolean fy){
		posX = x;
		posY = y;
		flipX = fx;
		flipY = fy;
	}
	
	//accessors
	public float getX(){
		return posX;
	}
	
	public float getY(){
		return posY;
	}
	
	public boolean isXFlipped(){
		return flipX;
	}
	
	public boolean isYFlipped(){
		return flipY;
	}
	
	public Location getLocation (){
		return new Location (this);
	}
	
	public String toString (){
		return "(" + getX() + ", " + getY() + ")";
	}
	
	//modifiers
	public void setX (float x){
		posX = x;
	}
	
	public void setY (float y){
		posY = y;
	}
	
	public void setXFlipped(boolean xf){
		flipX = xf;
	}
	
	public void setYFlipped(boolean yf){
		flipY = yf;
	}
	
	public void set (float x, float y, boolean fx, boolean fy){
		posX = x;
		posY = y;
		flipX = fx;
		flipY = fy;
	}
	
	public void set (Location loc){
		posX = loc.getX();
		posY = loc.getY();
		flipX = loc.isXFlipped();
		flipY = loc.isYFlipped();
	}
}
