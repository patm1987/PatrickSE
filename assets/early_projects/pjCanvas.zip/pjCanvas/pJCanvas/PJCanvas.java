/*
 * Created on May 10, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package pJCanvas;

import javax.swing.JComponent;
import java.util.Iterator;
import java.util.LinkedList;
import java.awt.*;
import java.awt.image.*;

/**
 * @author patm1987
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */

/*
 * This is the main canvas library, what makes the whole
 * program tick.  This is bound to the swing frontend, and
 * can only be used with swing or awt frontends.  if there is
 * a change in rendering techniques (opengl, sdl, efl), this
 * will have to be rewritten because it relies heavily on
 * awt/swing to work.  Changing the rendering interface should
 * ONLY effect PJCanvas and PJDesktop, no modules should be
 * deprecated as a result of such a change
 * 
 * What does this handle?
 * 	>3 layers (foreground, normal, and background) and each
 * module's position in said layer
 *  >Main buffer, the main buffer than is rendered to before
 * rendering to the screen
 *  >Adding and Removing of modules
 *  >Updating each individual module
 *  >finding a module at a specific location
 */
public class PJCanvas extends JComponent {
	private LinkedList[] Layers;
	private Dimension screenSize;
	
	/*TODO
	 * make custom Linked List class, so typecasting is no
	 * longer needed*/
	private LinkedList BackgroundLayer;
	private LinkedList DefaultLayer;
	private LinkedList ForegroundLayer;
	
	private BufferedImage myImageBuffer;
	
	//constructors
	public PJCanvas(){
		screenSize = this.getToolkit().getScreenSize();
		
		myImageBuffer = new BufferedImage(screenSize.width, screenSize.height, BufferedImage.TYPE_INT_RGB);
		
		this.setIgnoreRepaint(true);
		
		Layers = new LinkedList[3];
		
		BackgroundLayer = new LinkedList();
		DefaultLayer = new LinkedList();
		ForegroundLayer = new LinkedList();
		
		Layers[0] = BackgroundLayer;
		Layers[1] = DefaultLayer;
		Layers[2] = ForegroundLayer;
	}
	
	//accessors
	
	//modifiers
	public void addPJModule (PJModule mod){
		DefaultLayer.addLast(mod);
	}
	
	public void addPJModule (PJModule mod, int layer){
		Layers[layer].addLast(mod);
	}
	
	//come up with a more indepth removal method
	//this takes an int with 2 values, any more will be ignored
	//it will use the first to choose a layer, and the second
	//to choose which module in the layer to remove
	//untested and unimplemented, this module is unused, and
	//thus it was not necissary to test, it will be debugged if
	//it is ever needed
	public PJModule removePJModule (int[] layer){
		PJModule remMod = null;
		
		if (!(layer.length < 2)){
			if (!(Layers.length > layer[0]) &&
					!(Layers[layer[0]].size() > layer[1])){
				remMod = (PJModule)Layers[layer[0]].get(layer[1]);
				Layers[layer[0]].remove(layer[1]);
			}
		}
		return remMod;
	}
	
	/*Paint Method
	 * this is where it all happens
	 * 
	 * This will create a buffer, it will ask all modules to
	 * give it an image to render, calculate transparency, sfx
	 * , etc., then it will swap out the current screen with
	 * this buffer
	 * 
	 * */
	public void paint(Graphics g){
		
		//allows more complicated graphics
		Graphics2D g2d = (Graphics2D)g.create();
		
		//g2d.clearRect(0, 0, (int)screenSize.getWidth(), (int)screenSize.getHeight());
		
		BufferedImage myImageBuffer = new BufferedImage(screenSize.width, screenSize.height, BufferedImage.TYPE_INT_RGB);
		Graphics2D big2d = myImageBuffer.createGraphics();
		//draw each layer
		Iterator iter = null;
		PJModule temp = null;
		for (int x=0; x<Layers.length; x++){
			iter = Layers[x].iterator();
			while (iter.hasNext()){
				temp = (PJModule)iter.next();
				if (temp.isVisible())
					//the following line wants a "BufferedImageOp op" for null?
					/*
					 * the following code may appear pointless,
					 * but this is the purpose:
					 * 
					 * any module can be placed from any 1 corner
					 * 
					 * when you use the top left, for instance, then
					 * isXFlipped and isYFlipped are both false, but
					 * if you want the bottom, right corner, they
					 * are both true;
					 * 
					 * also, the top right corner would be:
					 * isXFlipped = true
					 * isYFlipped = false
					 * */
					if (!temp.isXFlipped() && !temp.isYFlipped()){
						big2d.drawImage(temp.update(),
								  null,
								  (int)((float)temp.getX()*screenSize.getWidth()),
								  (int)((float)temp.getY()*screenSize.getHeight()));
					}
					else if (!temp.isXFlipped() && temp.isYFlipped()){
						big2d.drawImage(temp.update(),
								  null,
								  (int)((float)temp.getX()*screenSize.getWidth()),
								  (int)((float)temp.getY()*screenSize.getHeight()-temp.getHeight()));
					}
					else if (temp.isXFlipped() && !temp.isYFlipped()){
						big2d.drawImage(temp.update(),
								  null,
								  (int)((float)temp.getX()*screenSize.getWidth()-temp.getWidth()),
								  (int)((float)temp.getY()*screenSize.getHeight()));
					}
					else{
						big2d.drawImage(temp.update(),
								  null,
								  (int)((float)temp.getX()*screenSize.getWidth()-temp.getWidth()),
								  (int)((float)temp.getY()*screenSize.getHeight()-temp.getHeight()));
					}
			}
		}
		g2d.drawImage(myImageBuffer, null, 0, 0);
		
		//get rid of it
		big2d.dispose();
		g2d.dispose();
	}
	
	//due to the length of time required by an update, an
	//update only recalls the current buffer, it does not
	//redraw to a new buffer and swap
	public void update(Graphics g){
		Graphics2D g2d = (Graphics2D)g.create();
		g2d.drawImage(myImageBuffer, null, 0, 0);
		g2d.dispose();
	}
	
	/*
	 * This returns a module given a location
	 * it takes into accound the ordering though it does not
	 * support shaped borders, i.e., if you're module is a 
	 * small circle of 2 pixels, and it says it is 50 pixels
	 * square, it will be detected as 50 pixels square
	 */
	public PJModule getModuleAt(Location loc){
		Iterator iter = null;
		PJModule tempMod = null;
		PJModule returnMod = null;
		
		for (int x=0; x<=2; x++){
			iter = Layers[x].iterator();
			while (iter.hasNext()){
				tempMod = (PJModule)iter.next();
				if (!tempMod.isXFlipped() && !tempMod.isYFlipped()){
					if (loc.getX() >= tempMod.getX()){
						if ((loc.getX()-tempMod.getX())*screenSize.getWidth() <= tempMod.getWidth()){
							if (loc.getY() >= tempMod.getY()){
								if ((loc.getY()-tempMod.getY())*screenSize.getHeight() <= tempMod.getHeight()){
									returnMod = tempMod;
								}
							}
						}
					}
				}
				
				else if (!tempMod.isXFlipped() && tempMod.isYFlipped()){
					if (loc.getX() >= tempMod.getX()){
						if ((loc.getX()-tempMod.getX())*screenSize.getWidth() <= tempMod.getWidth()){
							if (loc.getY() <= tempMod.getY()){
								if ((loc.getY()) >= tempMod.getY() - tempMod.getHeight()/screenSize.getHeight()){
									returnMod = tempMod;
								}
							}
						}
					}
				}
				
				if (tempMod.isXFlipped() && !tempMod.isYFlipped()){
					if (loc.getX() <= tempMod.getX()){
						if (loc.getX() >= tempMod.getX() - tempMod.getWidth()*screenSize.getWidth()){
							if (loc.getY() >= tempMod.getY()){
								if ((loc.getY()-tempMod.getY())*screenSize.getHeight() <= tempMod.getHeight()){
									returnMod = tempMod;
								}
							}
						}
					}
				}
				
				if (tempMod.isXFlipped() && tempMod.isYFlipped()){
					if (loc.getX() <= tempMod.getX()){
						if (loc.getX() >= tempMod.getX() - tempMod.getWidth()*screenSize.getWidth()){
							if (loc.getY() >= tempMod.getY()){
								if ((loc.getY()-tempMod.getY())*screenSize.getHeight() <= tempMod.getHeight()){
									returnMod = tempMod;
								}
							}
						}
					}
				}
				
			}
		}
		
		return returnMod;
	}
	
	
}
