/*
 * Created on May 10, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package pJCanvas;

import java.awt.image.BufferedImage;

/**
 * @author martinp
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
/*
 * PJModules are the basis of the PJDesktop
 * each module is a mini program or "applet" that will run
 * on a PJCanvas.
 * 
 * Modules may contain modules, this will be useful for objects
 * like buttons.  each module must manage contained modules on
 * it's own, including layering.  This may be useful for things
 * like buttons, and moving shapes.
 * 
 * This interface is the interface for a PJModule
 * if you do not impliment this... then ur module won't work
 * 
 * Fields and Descriptions:
 * 
 * Position:
 * * getPosition
 * * getX
 * * getY
 * * setPosition
 * * setX
 * * setY
 * * * this holds and sets the position of a module.  store it
 * * * however you like, PJCanvas just needs to be able to get
 * * * it and set it.  All positions are based on percentages
 * * * * 0 = 0%
 * * * * 1 = 100%
 * * * * 0.5 = 50%
 * * * (0, 0) is the upper left, and (1, 1) is the bottom right
 * * * your module will be placed relatively based on this
 * * *
 * * * 0 0           1 0
 * * *  |-------------|
 * * *  |             |
 * * *  |   canvas    |
 * * *  |             |
 * * *  |             |
 * * *  |-------------|
 * * * 0 1           1 1
 * 
 * Boundaries:
 * * getBounds
 * * getWidth
 * * getHeight
 * * setBounds
 * * setWidth
 * * setHeight
 * * * Bounds are Boundary objects.  They are maintained
 * * * currently as pixel amounts
 ****************************************
 *A Module will look something like this*
 ****************************************
 *|-------------------------|
 *|    %|------px-----------|
 *|     px                  |
 *|     |-------------------|
 *|-------------------------|
 *where px is pixels, and % is a percentage
 *all pixel sizes should be ints
 *all percentages should be floats
 *do not limit to between 0 and 1 for percents, it can be
 *offscreen
 *  
 * Visibility:
 * * isVisible
 * * setVisible
 * * * whether or not to actually render this module
 * * * true = visible
 * * * false = invisible
 * 
 * Update:
 * * update
 * * * application draws itself
 * * * APPLICATION MUST STAY WITHIN BOUNDS!!!
 * * * failure to do so may result in unexpected results
 * * * if you do not choose to heed this warning, a shaped object
 * * * may be able to appear to be outside of the bounds...
 * * * but there is no guarentee to this working, and you should
 * * * not rely on this
 * 
 * Mouse Events:
 * * onMouseover
 * * onMouseout
 * * onMouseclick
 * * * a function to run to allow mouse events in modules
 * * * without each function having it's own listener
 * * * * onMouseclick will be passed 3 arguments:
 * * * * * mouse button (1, 2, 3, 4, 5, 6, 7) corresponding to
 * * * * * the pressed button (note, unless your os switches
 * * * * * 6 and 7 to 4 and 5, applications will misread the
 * * * * * mousewheel on 5 button mice.  Most os's do this.
 * * * * * 
 * * * * * the floats being sent are the % position of the mouse in
 * * * * * reference to the top left corner of this module, not the
 * * * * * screen
 * * * * *
 * * * * * your module has the responsibility of passing mouse clicks
 * * * * * onto submodule's if necissary, this also includes changing
 * * * * * the position so it's relative to that module
 * 
 * * some modules (cough) buttons (cough) may not care about mouse
 * * position, and will have methods to the likewise
 * 
 * SetFlipped:
 * * isXFlipped
 * * isYFlipped
 * * setXFlipped
 * * setYFlipped
 * * * specify whether to set the location according to left
 * * * or right sides or top or bottom sides of the
 * * * Module
 * */

public interface PJModule {
	
	//accessors
	public Location getPosition();
	public float getX();
	public float getY();
	public boolean isXFlipped();
	public boolean isYFlipped();
	public Boundary getBounds();
	public int getWidth();
	public int getHeight();
	public boolean isVisible();
	public BufferedImage update ();
	
	//modifiers
	public void setPosition (Location loc);
	public void setPosition (float x, float y, boolean fx, boolean fy);
	public void setX (float x);
	public void setY (float y);
	public void setXFlipped(boolean fx);
	public void setYFlipped(boolean fy);
	public void setBounds (Boundary bound);
	public void setBounds (int width, int height);
	public void setWidth (int width);
	public void setHeight (int height);
	public void setVisible (boolean vis);
	public void onMouseover (float x, float y);
	public void onMouseout (float x, float y);
	public void onMouseclick (int button, float x, float y);
	
}
