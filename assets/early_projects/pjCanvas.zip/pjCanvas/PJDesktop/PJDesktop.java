/*
 * Created on May 11, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package PJDesktop;

import javax.swing.JFrame;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;

import pJCanvas.*;
import pJModules.Modules.*;

import java.util.*;

/**
 * @author patm1987
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 * 
 * What is this?
 * This is the actual window that displays the desktop
 * it handles controlling when to refresh, passing mouse clicks
 * to modules, and telling a module of a mousein or mouseout
 * 
 * what is this not?
 * it is not a canvas
 * it is not fast
 * this is a quick way of testing the lower level parts of this
 * project, due to the length of time required to implement
 * this is anything other than swing.  it is desired to get
 * this reduced to a native window, to be used as the root
 * window in linux, or an opengl canvas at the least to speed
 * rendering (look into ewl)
 * 
 * For the first release, this works great, though it can be
 * annoying with some of the required workarounds.
 */

/*
 * 
 * @author patm1987
 * 
 * note, eclipse makes this code much more readable
 * the outline allows easy location of desired methods
 * if you choose to use another ide or editor, you have been
 * warned.  Warning, Code may cause dizziness. ;-)
 *
 * TODO:
 * This is a todo list, some features may be placed in PJCanvas
 * 
 * support for the mobile hotspots now in modules
 * this allows modules to be placed by the other 3 corners
 * 
 * better opengl support (replace JCanvas w/ a derivative of
 * a lwgl or jogl awt opengl canvas type thing? use of 
 * Java 3d?)
 * 
 * more testing on windows, and speed enhancements on
 * Windows and Linux
 * 
 * faster rendering of the scene (rendering optimizations)
 * possibly calculating next position of all objects
 * immediatley after the last painting of the screen, rather
 * than directly before the painting that will put them on
 * 
 * a better algorithm than O(n) would be indefinately valuable
 * for onMouseover, onMouseout, and onMouseclick
 * 
 * ACTUALLY FILL IN THE JAVADOC COMMENTS
 * take documentation allergy medicine if necissary
 * 
 */
public class PJDesktop extends JFrame{
	private Container contentPane;
	private PJCanvas myCanvas;
	private static PJDesktop myPJDesktop;
	private Dimension screenSize;
	private Timer refreshTimer;
	private Random rand;
	private PJModule lastMod;
	
	//system dependent variables
	//these will detect your os's default options for a directory
	//slash and the current directory the user is in
	private final String SlashDir = System.getProperty("file.separator");
	private final String CurrentDir = System.getProperty("user.dir");
	
	//specify how many frames you want every second
	private final int Framerate = 15;

	public static void main(String[] args) {
		//the following line is experimental, disable if prog won't run
		String JDKVersion = System.getProperty("java.class.version","44.0");
		System.out.println(JDKVersion);
		if (JDKVersion.compareTo("49.0")>=0){
			//uncomment for experimental opengl rendering in
			//jdk 1.5, this has no effect on any version lower
			//than 1.5
			//System.setProperty("sun.java2d.opengl", "true");
		}
		System.out.println("opengl enabled: " + System.getProperty("sun.java2d.opengl"));
		myPJDesktop = new PJDesktop();
	}
	
	public PJDesktop(){
		contentPane = this.getContentPane();
		myCanvas = new PJCanvas();
		//get the size of the screen for determining percentage
		//positions.  Note, this application is meant to run
		//fullscreen in the background
		screenSize = this.getToolkit().getScreenSize();
		
		//the last selected mod
		lastMod = null;
		
		//random to get random values from
		rand = new Random();
		
		//set this up and load the modules
		setup();
		loadModules();
		
		//refresh x times every second
		refreshTimer = new Timer(true);
		System.out.println ("Set fps: " + Framerate + "\n" +
				"refresh " + 100/Framerate + " millisecond delay"
		);
		refreshTimer.scheduleAtFixedRate(new RefreshCycle(), 100, 100/Framerate);
		
		repaint();
		//while (true)repaint();
	}
	
	//setup the jframe
	private void setup(){
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setSize(screenSize);
		this.setBackground(Color.BLACK);
		//uncomment if you're not on windows for speed boost
		//this.setIgnoreRepaint(true);
		this.setUndecorated(true);
		this.setVisible(true);
		this.addMouseListener(new PJMouseListener());
		this.addMouseMotionListener(new PJMouseMotionListener());
		this.toBack();
	}
	
	//Place all modules to load here
	private void loadModules(){
		//experimental modules, very pointless
		
		//myCanvas.addPJModule(new testModule());
		//myCanvas.addPJModule(new testModule(.1f, .1f, 640, 480, new Color(.5f, .7f, .3f, .7f)));
		//myCanvas.addPJModule(new testModule(.002f, .002f, 640, 480, new Color (.85f, .15f, 0f, .95f)), 0);
		//myCanvas.addPJModule(new testModuleMove(.48f, .5f, .01f, 50, 50, new Color (1f, 1f, 1f, .5f)));
		//myCanvas.addPJModule(new testModuleMove(rand.nextFloat(), rand.nextFloat(), rand.nextFloat()/5, rand.nextInt(320), rand.nextInt(320), new Color (rand.nextFloat(), rand.nextFloat(), rand.nextFloat(), rand.nextFloat())));
		//myCanvas.addPJModule(new testButton(.3f, .45f));
		//myCanvas.addPJModule(new testBasicModule(.85f, .8f));
		
		//start testing real modules:
		
		backgroundModule background = new backgroundModule(CurrentDir + SlashDir + "wallpaper" + SlashDir + "Tech_Analysis_WP.jpg", (int)screenSize.getWidth(), (int)screenSize.getHeight());
		myCanvas.addPJModule(background, 0);
		
		clockModule clock = new clockModule();
		myCanvas.addPJModule(clock);
		
		//the iconbar take images and uses them as icons
		//each item is an image and a launch command
		IconBar iconBar = new IconBar(0f, 0f, 20);
		iconBar.addIcon(CurrentDir + SlashDir + "icons"+SlashDir+"gaim.png", "gaim");
		iconBar.addIcon(CurrentDir + SlashDir + "icons"+SlashDir+"limewire.png", "limewire");
		iconBar.addIcon(CurrentDir + SlashDir + "icons"+SlashDir+"mozilla.png", "explorer.exe");
		iconBar.addIcon(CurrentDir + SlashDir + "icons"+SlashDir+"kfm.png", "kfmclient exec " + System.getProperty("user.home"));
		iconBar.addIcon(CurrentDir + SlashDir + "icons"+SlashDir+"mplayer.png", "gmplayer");
		myCanvas.addPJModule(iconBar);
		
		//Lauch menu handles strings only
		//so each item is a string which is drawn, and the
		//second option is the command to run
		launchMenu myLaunchMenu = new launchMenu(0, 1, false, true, 15);
		myLaunchMenu.addItem("Explorer", "explorer.exe");
		myLaunchMenu.addItem("Notepad", "notepad.exe");
		myLaunchMenu.addItem("Calculator", "calc.exe");
		myLaunchMenu.addItem("Paint", "mspaint.exe");
		myCanvas.addPJModule(myLaunchMenu, 2);
		
		//this.repaint();
		//myCanvas.repaint();
	}
	
	public void paint(Graphics g){
		//only paint one thing
		myCanvas.paint(g);
	}
	
	public void update(Graphics g){
		//update calls paint
		paint(g);
	}
	
	//every screen update
	public class RefreshCycle extends TimerTask{
		public void run(){
			if (myPJDesktop != null){
				myPJDesktop.repaint();
				//myPJDesktop.toBack(); //Uncomment in order to have default "to back" behavior
			}
		}
	}
	
	//listen for mouseclicks
	private class PJMouseListener implements MouseListener{

		/* (non-Javadoc)
		 * @see java.awt.event.MouseListener#mouseClicked(java.awt.event.MouseEvent)
		 */
		public void mouseClicked(MouseEvent arg0) {
			// TODO Auto-generated method stub
			int mouseX = arg0.getX();
			int mouseY = arg0.getY();
			int mouseButton = arg0.getButton();
			
			PJModule selMod = myCanvas.getModuleAt(new Location((float)(mouseX/screenSize.getWidth()), (float)(mouseY/screenSize.getHeight())));
			
			//change
			if (selMod != null){
				if (!selMod.isXFlipped() && !selMod.isYFlipped()){
					selMod.onMouseclick(mouseButton, (float)((mouseX-selMod.getX()*screenSize.getWidth())/selMod.getWidth()), (float)((mouseY-selMod.getY()*screenSize.getHeight())/selMod.getHeight()));
				}
				if (!selMod.isXFlipped() && selMod.isYFlipped()){
					selMod.onMouseclick(mouseButton, (float)((mouseX-selMod.getX()*screenSize.getWidth())/selMod.getWidth()), -1*(float)((mouseY-selMod.getY()*screenSize.getHeight())/selMod.getHeight()));
				}
			}
		}

		/* (non-Javadoc)
		 * @see java.awt.event.MouseListener#mousePressed(java.awt.event.MouseEvent)
		 */
		public void mousePressed(MouseEvent arg0) {
			// TODO Auto-generated method stub
			
		}

		/* (non-Javadoc)
		 * @see java.awt.event.MouseListener#mouseReleased(java.awt.event.MouseEvent)
		 */
		public void mouseReleased(MouseEvent arg0) {
			// TODO Auto-generated method stub
			
		}

		/* (non-Javadoc)
		 * @see java.awt.event.MouseListener#mouseEntered(java.awt.event.MouseEvent)
		 */
		public void mouseEntered(MouseEvent arg0) {
			// TODO Auto-generated method stub
			
		}

		/* (non-Javadoc)
		 * @see java.awt.event.MouseListener#mouseExited(java.awt.event.MouseEvent)
		 */
		public void mouseExited(MouseEvent arg0) {
			// TODO Auto-generated method stub
			
		}
		
	}
	
	//listen for mouseovers and mouseouts
	public class PJMouseMotionListener implements MouseMotionListener{

		/* (non-Javadoc)
		 * @see java.awt.event.MouseMotionListener#mouseDragged(java.awt.event.MouseEvent)
		 */
		public void mouseDragged(MouseEvent arg0) {
			// TODO Auto-generated method stub
			
		}

		/* (non-Javadoc)
		 * @see java.awt.event.MouseMotionListener#mouseMoved(java.awt.event.MouseEvent)
		 */
		public void mouseMoved(MouseEvent arg0) {
			// TODO Auto-generated method stub
			int mouseX = arg0.getX();
			int mouseY = arg0.getY();
			
			PJModule testMod = myCanvas.getModuleAt(new Location((float)(arg0.getX()/screenSize.getWidth()), (float)(arg0.getY()/screenSize.getHeight())));
			
			if (lastMod != null){
				lastMod.onMouseout((float)((mouseX-lastMod.getX()*screenSize.getWidth())/lastMod.getWidth()),
						(float)((mouseY-lastMod.getY()*screenSize.getHeight())/lastMod.getHeight()));
			}
			
			lastMod = testMod;
			
			if (testMod != null){
				testMod.onMouseover(
						(float)((mouseX-testMod.getX()*screenSize.getWidth())/testMod.getWidth()),
						(float)((mouseY-testMod.getY()*screenSize.getHeight())/testMod.getHeight()));
			}
		}
		
	}
}
